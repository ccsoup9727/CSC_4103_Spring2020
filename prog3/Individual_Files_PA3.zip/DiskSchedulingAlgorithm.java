/* Name: Campbell, Casey
 * Project: PA-3 (Disc Algorithms)
 * DiskSchedulingAlgorithm for PA3
 * Instructor: Feng Chen
 * Class: cs4103-sp20
 * cs410313
 */

package prog3;
import java.io.*;
import java.util.*;

public class DiskSchedulingAlgorithm {

    public static void main(String[] args) throws FileNotFoundException, Exception
    {
        //Prompts user to enter command line arguments to set current head, max blocks, algorithm, and file.


        try{
            int currentHead = Integer.parseInt(args[0]);
            int maximumBlock  = Integer.parseInt(args[1]);
            String algorithm = args[2];
            String file = args[3];
        } catch(Exception e){
            throw new Exception("ERROR: Invalid command line args.\nPlease provide Algorithm (String), Cache Size (Integer), Input File Name (String) as command line arguments.", e);
        }
        int currentHead = Integer.parseInt(args[0]);
        int maximumBlock  = Integer.parseInt(args[1]);
        String algorithm = args[2];
        String file = args[3];
        
        
        Scanner scn = new Scanner(new File(file));
        String req ="";
        
        while (scn.hasNextLine())
            req = req + scn.nextLine() + " ";
        
        req = req.substring(0, req.length()-1);
        String []s = req.split(" ");
        ArrayList<Integer> data = new ArrayList<Integer>( s.length );
       
   
        for(int i=0; i<s.length; i++)
            data.add( Integer.parseInt(s[i]) );
        //END scanning of page files

        Disk disk = new Disk();
        
        //Begins actual scheduling
        if(algorithm.equalsIgnoreCase("FCFS") == true)
        {
        	disk.fcfs(currentHead, maximumBlock, data);
        }
        else if(algorithm.equalsIgnoreCase("SSTF") == true)
        {
        	disk.sstf(currentHead, maximumBlock, data);
        }
        else if(algorithm.equalsIgnoreCase("SCAN") == true)
        {
        	disk.scan(currentHead, maximumBlock, data);
        }
        else{
            System.out.printf("Algorithm inproperly defined. Please provide one of the given algorithm arguments.\n");
        }
        //End of scheduling
        scn.close();  
    }
}

