/* Name: Campbell, Casey
 * Project: PA-3 (Disc Algorithms)
 * Disk.java for PA3
 * Instructor: Feng Chen
 * Class: cs4103-sp20
 * cs410313
 */

package prog3;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.Random;

public class Disk {
	 public void fcfs(int current, int maximumBlock, ArrayList<Integer> data)
	   {
	       // total stores service time and order stores the ordering
	       int t_dis = 0;
	       double t_seek = 0;
	       double t_rotational_Latency = 0;
	       double t_transfer = 0;
	       double t_access = 0;
	       
	       Iterator itr = data.iterator();
	       int order;
	       order = 1;
	       // Accessing the service request in order of arrival
	       while( itr.hasNext() )
	       {
	           int temp = (int)itr.next();
	           if( temp >= maximumBlock )
	           {
	        	   // The service request block number is greater than the max block number!
	               System.out.println("The service request block number is greater than the max block number!");
	               System.exit(0);
	           }
	           
	           //variables for output
	           int distance = (int)Math.abs(temp-current);
	           double seek = distance * .01;
	           Random rd = new Random();
	           double rot_lat = rd.nextFloat() * 8.3;
	           double transfer = .031;
	           double access = seek + rot_lat + transfer;
	           // Outputs
	           
	           System.out.printf("Target Disk: %d   currentrent Disk: %d   Distance: %d%n"+
	        		   			 "Seek Time: %.4f   Rotational Lat: %.4f   Transfer Time: %.4f   Access Time: %.4f%n",
	        		   			 temp, current, distance, seek, rot_lat, transfer, access);

	           
	           order++;
	           current = temp;
	           
	           t_dis += distance;
	           t_seek += seek;
	           t_rotational_Latency += rot_lat;
	           t_transfer += transfer;
	           t_access += access;
	       }
	       
	       System.out.printf("%n%nTotal Requests: %d   Total Distance: %d   Total Seek: %.4f%n"+
	    		   			 "Total Rotational Lat: %.3f   Total Transfer: %.3f   Total Access: %.3f", 
	    		   			 order, t_dis,t_seek, t_rotational_Latency, t_transfer, t_access);
	   }
	 public void sstf(int current, int maximumBlock, ArrayList<Integer> data)
	 {
		// total stores service time and order stores the ordering  
	       int t_dis = 0;
	       double t_seek = 0;
	       double t_rotational_Latency = 0;
	       double t_transfer = 0;
	       double t_access = 0;
	       
	       int order;
	       order = 1;
	       while( data.size() != 0 )
	       {
	           Iterator itr = data.iterator();
	           // Finding the service reuqest which is nearest to current (currentrent postion)
	           int min_diff = Integer.MAX_VALUE;
	           int min = 0;
	           while( itr.hasNext() )
	           {
	               int temp = (int)itr.next();
	               int diff = (int)Math.abs(temp-current);
	               if(diff < min_diff)
	               {
	                   min = temp;
	                   min_diff = diff;
	               } 
	               
	           }
	           // min is the nearest service request
	           int index = data.indexOf(min);
	           data.remove(index);
	           // removing it from data list
	           if( min >= maximumBlock )
	           {
	               System.out.println("The service request block number is greater than the max block number!");
	               System.exit(0);
	           }
	           // Computing service time          
	         //variables for output
	           int distance = (int)Math.abs(min-current);
	           double seek = distance * .01;
	           Random rd = new Random();
	           double rot_lat = rd.nextFloat() * 8.3;
	           double transfer = .031;
	           double access = seek + rot_lat + transfer;
	           // Outputs
	           System.out.printf("Target Disk: %d   currentrent Disk: %d   Distance: %d%n"+
  		   			 "Seek Time: %.4f   Rotational Lat: %.4f   Transfer Time: %.4f   Access Time: %.4f%n",
  		   			 min, current, distance, seek, rot_lat, transfer, access);
	           order++;
	           current = min;
	           
	           t_dis += distance;
	           t_seek += seek;
	           t_rotational_Latency += rot_lat;
	           t_transfer += transfer;
	           t_access += access;
	       }
	       System.out.printf("%n%nTotal Requests: %d   Total Distance: %d   Total Seek: %.4f%n"+
		   			 "Total Rotational Lat: %.3f   Total Transfer: %.3f   Total Access: %.3f", 
		   			 order, t_dis,t_seek, t_rotational_Latency, t_transfer, t_access);
	 }
	   public static void scan(int current, int maximumBlock, ArrayList<Integer> data)
	   {
	       int t_dis = 0;
	       double t_seek = 0;
	       double t_rotational_Latency = 0;
	       double t_transfer = 0;
	       double t_access = 0;
	       
	       int order;
	       order = 1;
	       // Direction is 0 if head is near towards 0th end and 1 if head is near maximumBlock end
	       int direction = (current < maximumBlock-current) ? 0 : 1;
	      
	       // obj1 contains all service request smaller than current (currentrent position)
	       // obj2 contains all service request greater than current (currentrent position)      
	       ArrayList<Integer> obj1 = new ArrayList<Integer>();
	       ArrayList<Integer> obj2 = new ArrayList<Integer>();      
	       Iterator itr = data.iterator();
	       while( itr.hasNext() )
	       {
	           int temp = (int)itr.next();
	           if( temp >= maximumBlock )
	           {
	               System.out.println("The service request block number is greater than the max block number!");
	               System.exit(0);
	           }
	           if(temp <= current)
	               obj1.add(temp);
	           if(temp > current)
	               obj2.add(temp);
	       }
	      
	       // Head will service obj1 first, then obj2
	       if(direction == 0)
	       {
	           while( obj1.size() !=0 )
	           {
	               // Finding max request in obj1 and removing it
	               int temp = Collections.max(obj1);
	               int index = obj1.indexOf(temp);
	               obj1.remove(index);
	               
	               int distance = (int)Math.abs(temp-current);
		           double seek = distance * .01;
		           Random rd = new Random();
		           double rot_lat = rd.nextFloat() * 8.3;
		           double transfer = .031;
		           double access = seek + rot_lat + transfer;
		           // Outputs
		           System.out.printf("Target Disk: %d   currentrent Disk: %d   Distance: %d%n"+
      		   			 "Seek Time: %.4f   Rotational Lat: %.4f   Transfer Time: %.4f   Access Time: %.4f%n",
      		   			 temp, current, distance, seek, rot_lat, transfer, access);
		           
		           order++;
		           current = temp;
		           
		           t_dis += distance;
		           t_seek += seek;
		           t_rotational_Latency += rot_lat;
		           t_transfer += transfer;
		           t_access += access;;
	           }
	           // current is at 0 now
	           current = 0;
	           while( obj2.size() !=0 )
	           {
	               // Finding min request in obj1 and removing it          
	               int temp = Collections.min(obj2);
	               int index = obj2.indexOf(temp);
	               obj2.remove(index);
	               
	               int distance = (int)Math.abs(temp-current);
		           double seek = distance * .01;
		           Random rd = new Random();
		           double rot_lat = rd.nextFloat() * 8.3;
		           double transfer = .031;
		           double access = seek + rot_lat + transfer;
		           // Outputs
		           System.out.printf("Target Disk: %d   currentrent Disk: %d   Distance: %d%n"+
      		   			 "Seek Time: %.4f   Rotational Lat: %.4f   Transfer Time: %.4f   Access Time: %.4f%n",
      		   			 temp, current, distance, seek, rot_lat, transfer, access);
		           
		           order++;
		           current = temp;
		           
		           t_dis += distance;
		           t_seek += seek;
		           t_rotational_Latency += rot_lat;
		           t_transfer += transfer;
		           t_access += access;
	           }
		       System.out.printf("%n%nTotal Requests: %d   Total Distance: %d   Total Seek: %.4f%n"+
  		   			 "Total Rotational Lat: %.3f   Total Transfer: %.3f   Total Access: %.3f", 
  		   			 order, t_dis,t_seek, t_rotational_Latency, t_transfer, t_access);      
	       }
	       else
	       {
	           // Head will service obj1 first, then obj2      
	           while( obj2.size() !=0 )
	           {
	               // Finding min request in obj1 and removing it              
	               int temp = Collections.min(obj2);
	               int index = obj2.indexOf(temp);
	               obj2.remove(index);
	               
	               int distance = (int)Math.abs(temp-current);
		           double seek = distance * .01;
		           Random rd = new Random();
		           double rot_lat = rd.nextFloat() * 8.3;
		           double transfer = .031;
		           double access = seek + rot_lat + transfer;
		           // Outputs
		           System.out.printf("Target Disk: %d   currentrent Disk: %d   Distance: %d%n"+
      		   			 "Seek Time: %.4f   Rotational Lat: %.4f   Transfer Time: %.4f   Access Time: %.4f%n",
      		   			 temp, current, distance, seek, rot_lat, transfer, access);
		           
		           order++;
		           current = temp;
		           
		           t_dis += distance;
		           t_seek += seek;
		           t_rotational_Latency += rot_lat;
		           t_transfer += transfer;
		           t_access += access;
	           }
	           // current is at maximumBlock-1
	           current = maximumBlock-1;
	           while( obj1.size() !=0 )
	           {
	               // Finding max request in obj1 and removing it                      
	               int temp = Collections.max(obj1);
	               int index = obj1.indexOf(temp);
	               obj1.remove(index);
	               
	               int distance = (int)Math.abs(temp-current);
		           double seek = distance * .01;
		           Random rd = new Random();
		           double rot_lat = rd.nextFloat() * 8.3;
		           double transfer = .031;
		           double access = seek + rot_lat + transfer;
		           // Outputs
		           System.out.printf("Target Disk: %d   currentrent Disk: %d   Distance: %d%n"+
      		   			 "Seek Time: %.4f   Rotational Lat: %.4f   Transfer Time: %.4f   Access Time: %.4f%n",
      		   			 temp, current, distance, seek, rot_lat, transfer, access);
		           
		           order++;
		           current = temp;
		           
		           t_dis += distance;
		           t_seek += seek;
		           t_rotational_Latency += rot_lat;
		           t_transfer += transfer;
		           t_access += access;
	           }
	           
		       System.out.printf("%n%nTotal Requests: %d   Total Distance: %d   Total Seek: %.4f%n"+
  		   			 "Total Rotational Lat: %.3f   Total Transfer: %.3f   Total Access: %.3f", 
  		   			 order, t_dis,t_seek, t_rotational_Latency, t_transfer, t_access);
	       }
	   }
}

