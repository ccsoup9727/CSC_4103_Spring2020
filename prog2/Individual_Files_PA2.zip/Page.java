/* Name: Campbell, Casey
 * Project: PA-2 (Page Replacement Algorithm)
 * Clock.java
 * Instructor: Feng Chen
 * Class: cs4103-sp20
 * cs410313
 */

package prog2;

public class Page
{	

	//action performed
	private String action;

	//int to hold ID
	private int pID;

	//boolean for writing
	boolean modifyBit;

	//boolean for recent ref
	boolean referenceBit;

	//page constructor
	public Page(String pageAction, int pageID)
	{
		//action == passed value
		action = pageAction;

		//pID == passed value
		pID = pageID;

		if(action.equalsIgnoreCase("W")){
			modifyBit = true;
		}
		else{
			modifyBit = false;
		}

		referenceBit = false;
	}

	//return if modify
	public boolean getWriteStatus()
	{
		if(this.modifyBit == true)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	public int getPageID()
	{
		return this.pID;
	}

	public boolean getRefBit()
	{
		if(referenceBit == true)
		{
			return true;
		}
		else{
			return false;
		}
	}

	public void setRefBit(boolean bit)
	{
		this.referenceBit = bit;
	}
}
