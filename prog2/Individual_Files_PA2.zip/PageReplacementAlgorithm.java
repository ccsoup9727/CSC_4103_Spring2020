/* Name: Campbell, Casey
 * Project: PA-2 (Page Replacement Algorithm)
 * Clock.java
 * Instructor: Feng Chen
 * Class: cs4103-sp20
 * cs410313
 */

package prog2;

import java.io.*;
import java.util.*;

public class PageReplacementAlgorithm {
	
	
	//MAIN Class
    public static void main(String[] args) throws FileNotFoundException, Exception
    {
        //Uses command line arguments to set algorithm, cache size, and the input file name
       /* try{
            String algorithm = args[0]; //only clock
            int cacheSize = Integer.parseInt(args[1]);
            String inputFile = args[2];
            int hitTime = Integer.parseInt(args[3]);
            int swapInTime = Integer.parseInt(args[4]);
            int swapOutTime = Integer.parseInt(args[5]);
            
        } catch(Exception e){
            throw new Exception("ERROR: Invalid command line args.\nPlease only use Clock (String), Cache Size (Integer), "
            		+ "Input File Name (String), Hit Time (Integer), "
            		+ "Swap In Time (Integer), and Swap Out Time (Integer) as command line arguments.", e);
        }
        String algorithm = args[0]; //only clock
        int cacheSize = Integer.parseInt(args[1]);
        String inputFile = args[2];
        int hitTime = Integer.parseInt(args[3]);
        int swapInTime = Integer.parseInt(args[4]);
        int swapOutTime = Integer.parseInt(args[5]);*/
    	
        String algorithm = "Clock"; //only clock
        int cacheSize = 20;
        String inputFile = "pageref.txt";
        int hitTime = 1;
        int swapInTime = 10;
        int swapOutTime = 20;
        
    	Scanner scan = new Scanner(new File(inputFile));
        Scanner scn = new Scanner(new File(inputFile));
        
        int numPage_scheduled = 0;
        
        while(scn.hasNextLine() == true)
        {
            numPage_scheduled++;
            scn.nextLine();
        }
        Page pageTable[] = new Page[numPage_scheduled];   //Array to hold all imported Page Files
        int i = 0;
        while(scan.hasNext() == true)
        {  
            pageTable[i] = new Page(scan.next(), scan.nextInt());
            
            i++;
        }

        //Starts scheduling process
        if(algorithm.equalsIgnoreCase("clock") == true)
        {	
        	Clock cache = new Clock(cacheSize, pageTable, hitTime, swapInTime, swapOutTime);
            Clock.Schedule(pageTable);
        }
        else{
            System.out.printf("Algorithm improperly defined, please provide either 'LRU' or 'CLOCK' as algorithm argument.\n");
        }
        //Ends scheduling process
        scan.close();
        scn.close();
    }
}


