/* Name: Campbell, Casey
 * Project: PA-2 (Page Replacement Algorithm)
 * Clock.java
 * Instructor: Feng Chen
 * Class: cs4103-sp20
 * cs410313
 */

package prog2;

public class ClockIterator
{
	//int for iterator index
	private static int index;

	//int for cache cap
	private int cache_atCapacity;

	//iterator constructor
	public ClockIterator(int cacheSize)
	{
		index = 0;
		cache_atCapacity = cacheSize;
	}

	public void next()
	{
		if(cache_atCapacity < index-1){
			index++;
		}
		if(cache_atCapacity == index-1){
			index = 0;
		}
	}

	public static int getIndex()
	{
		return index;
	}
}
