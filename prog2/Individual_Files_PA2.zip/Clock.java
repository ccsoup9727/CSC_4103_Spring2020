/* Name: Campbell, Casey
 * Project: PA-2 (Page Replacement Algorithm)
 * Clock.java
 * Instructor: Feng Chen
 * Class: cs4103-sp20
 * cs410313
 */

package prog2;

import java.util.*;

public class Clock
{
	//int for cap
	private static int atCapacity;

	//int for # or refs
	private static int numPage_ref;
	
	//hold time to access page
	private static int hitTime;
	
	//total access time
	private static int total_hitTime;
	
	//hold time to swap out page
	private static int swapOut_Time;
	
	//total out time
	private static int totalswapOut_Time;
	
	//hold time to swap in page
	private static int swapIn_Time;
	
	//total in time
	private static int totalswapIn_Time;

	//linked list for cache pages
	private static LinkedList<Page> cache = new LinkedList<Page>();

	//tracking pointer
	private static int iterator;
	
	//tracking read faults
	private static int pageFaultRead;
	
	//tracking write faults
	private static int pageFaultWrite;

	//Constructor for the clock data structure
	public Clock(int cacheatCapacity, Page[] pageTable, int hitTimeVar, int swapIn_TimeVar, int swapOut_TimeVar)
	{
		atCapacity = cacheatCapacity;
		hitTime = hitTimeVar;
		swapIn_Time = swapIn_TimeVar;
		swapOut_Time = swapOut_TimeVar;
		numPage_ref = 0;
		iterator = 0;
		pageFaultRead = 0;
		pageFaultWrite = 0;
	}

	//schedule provided pages using the clock algorithm
	public static void Schedule(Page[] pageTable)
	{
		total_hitTime = 0;
		totalswapIn_Time = 0;
		totalswapOut_Time = 0;
		for(int i = 0; i < pageTable.length; i++)
		{
			Clock.bufferPage(pageTable[i]);
		}
		System.out.printf("Total # of page references = %d\n", numPage_ref);
		System.out.printf("Total # of page faults on read = %d Time Units\n", pageFaultRead);
		System.out.printf("Total # of page faults on write = %d Time Units\n", pageFaultWrite);
		System.out.printf("Total time elapsed accessing pages in memory = %d Time Units\n",total_hitTime);
		System.out.printf("Total time elapsed swapping in pages = %d Time Units\n", totalswapIn_Time);
		System.out.printf("Total time elapsed swapping out pages = %d Time Units\n", totalswapOut_Time);
	}

	//loading a Page File into the cache
	private static void bufferPage(Page nPage)
	{
		numPage_ref++;
		int index = Clock.searchCache(nPage);
		
		//Cache Empty
		if(Clock.isFull() == false)
		{
			//Cache Miss while cache is not full
			if(index == -1){
				Clock.addPage(nPage);
				
				if (cache.get(ClockIterator.getIndex()).getWriteStatus() == true) {
					pageFaultWrite++;
				}
				else {
					pageFaultRead++;
				}
				totalswapIn_Time += swapIn_Time;
			}
			//Cache hit while cache is not full
			else{
				cache.get(index).setRefBit(true);
				total_hitTime += hitTime;
			}
		}
		//Cache full
		else{
			//Cache Miss while cache is full
			if(index == -1){
				Clock.addPage(nPage, Clock.evictPage());
				
				if (cache.get(ClockIterator.getIndex()).getWriteStatus() == true) {
					pageFaultWrite++;
				}
				else {
					pageFaultRead++;
				}
				totalswapIn_Time += swapIn_Time;

			}
			//Cache Hit while cache is full
			else{
				cache.get(index).setRefBit(true);
				
				total_hitTime += hitTime;
			}
		} 
	}

	//method for choosing a victim to evict when cache miss and cache is full
	private static int evictPage()
	{
		ClockIterator arm = new ClockIterator(atCapacity);

		while(cache.get(ClockIterator.getIndex()).getRefBit() == true)
		{
			if(cache.get(ClockIterator.getIndex()) == null){
				break;
			}
			
			if(cache.get(ClockIterator.getIndex()).getRefBit() == true)
			{
				cache.get(ClockIterator.getIndex()).setRefBit(false);
				arm.next();
			}
		}
		if(cache.get(ClockIterator.getIndex()).getWriteStatus() == true){
			totalswapOut_Time += swapOut_Time;
		}
		cache.remove(ClockIterator.getIndex());
		return ClockIterator.getIndex();
	}

	//adds a new page to the cache at specified index
	private static void addPage(Page nPage, int index)
	{
		cache.add(index, nPage);
		
	}

	//adds a new page to the cache
	private static void addPage(Page nPage)
	{
		cache.add(nPage);
		
	}

	//Is cache full?
	private static boolean isFull()
	{
		if(cache.size() >= Clock.atCapacity) {
			return true;
		}
		else{
			return false;
		}
	}

	//Helper method for searching the cache, returns -1 if not found
	private static int searchCache(Page targetPage)
	{
		for(int i = 0; i < cache.size(); i++)
		{
			if(cache.get(i).getPageID() == targetPage.getPageID())
			{
				return i;
			}
		}
		return -1;
	}
}


